import boto3
from collections import OrderedDict
from urllib import urlencode
import requests
import json

class Business(object):
    id = ""
    name = ""

def as_business(data):
    b = Business()
    b.__dict__.update(data)
    return b

def build_response(message):
    return {
        "dialogAction" : {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {
                "contentType" : "PlainText",
                "content" : message
            }
        }
    }

def get_data(term, zipcode):
    params = OrderedDict([('terms', term), ('limit', 5), ('location', zipcode)])
    header = {"Authorization" : "Bearer outA7A9vl33IeXwW9tutILDsr865KzoCRwJ98KPzBfkF9ZUEQ2WAxlYjTdtdiwUNy5Sm1mcmxcrBOEDYLy8oWZYdimI-Vzt__r8zcNTUDxWY47Veu1zW8anZre1TWXYx "}
    response = requests.get('https://api.yelp.com/v3/businesses/search', params=urlencode(params), headers = header)
    data =  json.loads(response.content)
    list_business = []
    for item in data["businesses"]:
        new_data = json.dumps(item)
        o = json.loads(new_data, object_hook=as_business)
        list_business.append(o)
    return list_business

def lambda_handler(event, context):
    if "LocationIntent" == event['currentIntent']['name']:
        term = event['currentIntent']['slots']['term']
        zipcode = event['currentIntent']['slots']['zipcode']
        response = get_data(term, zipcode)
    i = 1    
    s = ""
    for item in response:
        s = i + ". " + item.name + "\n"
    return build_response(s)
