import boto3
from collections import OrderedDict
from urllib import urlencode
import requests
import json

class Response(object):
    total = None

def as_business(data):
    b = Response()
    b.__dict__.update(data)
    return b

def build_response(message):
    return {
        "dialogAction" : {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {
                "contentType" : "PlainText",
                "content" : message
            }
        }
    }

def get_data(term, zipcode):
    params = OrderedDict([('terms', term), ('limit', 5), ('location', zipcode)])
    header = {"Authorization" : "Bearer outA7A9vl33IeXwW9tutILDsr865KzoCRwJ98KPzBfkF9ZUEQ2WAxlYjTdtdiwUNy5Sm1mcmxcrBOEDYLy8oWZYdimI-Vzt__r8zcNTUDxWY47Veu1zW8anZre1TWXYx "}
    response = requests.get('https://api.yelp.com/v3/businesses/search', params=urlencode(params), headers = header)
    list_business = []
    data = json.loads(response.content, object_hook=as_business) 
    for item in data.businesses:
        list_business.append(item)
    return list_business

def handler(event, context):
    if "LocationIntent" == event['currentIntent']['name']:
        term = event['currentIntent']['slots']['term']
        zipcode = event['currentIntent']['slots']['location']
        resp = get_data(term,zipcode)
    s = ""
    i = 0
    for item in resp:
        s += i + ". " + item.name + "\n"
        i += 1
    return build_response(s)